def verificar_acao(valor):
    if valor > 150.99:
        return "Ação está cara! Compre com cuidado."
    else:
        return "Ação está barata!"